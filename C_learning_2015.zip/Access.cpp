#include <stdio.h>
#include<string.h>

typedef struct{
	char name[20];
	int score[3];
} Student;

Student* student_input(Student *pStudent){
	scanf("%s",pStudent->name);
	scanf("%d",&pStudent->score[0]);
	scanf("%d",&pStudent->score[1]); 
	scanf("%d",&pStudent->score[2]);
	return pStudent; 
}//����һ��ѧ��������

void student_print(const Student *pStudent){
	printf("%s\t%d\t%d\t%d\t",pStudent->name,pStudent->score[0],pStudent->score[1],pStudent->score[2]);
}//���һ��ѧ�������ݣ�����ƽ���ɼ�

double student_average(const Student *pStudent){
	double sum=0.0;
	int cnt=0;
	double result=0.0;
	while(cnt<sizeof(pStudent->score)/sizeof(pStudent->score[0])){
		sum+=pStudent->score[cnt++];
	}
	return result=sum/cnt;
}//����һ��ѧ����ƽ���ɼ�

int student_get_score(const Student *pStudent, int index){
	return pStudent->score[index-1];
}//���ѧ����һ���ɼ�

void print_three(const Student pStudent[]){
	int subjects[10][3];
	int min[]={10,10,10,};
	int max[]={0,0,0,};
	printf("average\t\t");
	for(int cnt=0;cnt<10;cnt++){
		for(int i=0;i<3;i++){
			subjects[cnt][i]=pStudent[cnt].score[i];
		}
	}
	for(int i=0;i<3;i++){
		double sum=0.0;		
		for(int j=0;j<10;j++){
			sum+=subjects[j][i];
			if(min[i]>subjects[j][i]){
				min[i]=subjects[j][i]; 
			}
			if(max[i]<subjects[j][i]){
				max[i]=subjects[j][i];
			}
		}
		printf("%lf\t",sum/10);
	}
	printf("\nmin\t\t");
	for(int i=0;i<3;i++){
		printf("%d\t",min[i]);
	}
	printf("\nmax\t\t");
	for(int i=0;i<3;i++){
		printf("%d\t",max[i]);
	}
}
 
int main(int argc,char const *argv[]){
	Student students[10];
	for(int cnt=0;cnt<10;cnt++){
		student_input(&students[cnt]);
	}
	printf("%s\t%s\t%s\t%s\t%s\t%s\n","no","name","score1","score2","score3","average");
	for(int cnt=0;cnt<10;cnt++){
		printf("%d\t",cnt+1);
		student_print(&students[cnt]);
		printf("%lf\n",student_average(&students[cnt]));
	}
	print_three(students);
	printf("\n");
	char name[20];
	int subject=0;
	scanf("%s",name);
	scanf ("%d",&subject);
	for(int i=0;i<10;i++){
		if(strcmp(students[i].name,name)==0){
			printf("%d",student_get_score(&students[i],subject));
			break;
		}
	}
}
