#include <stdio.h>
#include <stdlib.h>

typedef struct _list{
	int value;
	_list* next;
}List;

typedef struct{
	List* head; 
	List* tail;
}Link; 
 
void add(Link*plink,int input);

void myprint(const Link* prin);

int main(int argc,char* argv[]){	
	Link link;
	link.head=NULL; 
	link.tail=NULL;
	int number=0;
	do{
		number=0;
		scanf("%d",&number);
		if(number!=-1){
			add(&link,number); 
		} 
	}while(number!=-1);
	myprint(&link);
	return 0;
}

void add(Link* plink,int input){
	List* p=(List*)malloc(sizeof(List));
	p->value=input;
	p->next=NULL;
	//find the last
	if(plink->tail){
		plink->tail->next=p; 
		plink->tail=p;
	}else{
		plink->head=p;
		plink->tail=plink->head;
	} 
} 

void myprint(const Link* prin){
	List *p;
	for(p=prin->head;p;p=p->next){
		printf("%d\t",p->value);
	}
}
