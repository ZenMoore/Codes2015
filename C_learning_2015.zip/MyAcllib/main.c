#include "acllib.h"
#include <stdio.h>

int Setup(){
	initWindow("title",100,100,800,800);
	beginPaint();
		setBrushColor(BLUE);
		setBrushStyle(BRUSH_STYLE_SOLID); 
		chrod(70,70,200,200,200,200,0,0);
	endPaint();
	return 0;
}
