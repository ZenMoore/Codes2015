#include<stdio.h>
#include<string.h>
void Initialize(char a[150]){
	for(int i=0;i<150;i++){
		a[i]='#';
	} 
} 
void getNumber(int a[150]){
	int one=0,two=0,three=0,four=0,five=0,six=0,seven=0,eight=0,nine=0,ten=0;
	for(int i=1;i<150&&a[i]!=0;i++){
		if(a[i]==1)	 one++;
		else if(a[i]==2)	two++;
		else if(a[i]==3)	three++;
		else if(a[i]==4)	four++;
		else if(a[i]==5)	five++;
		else if(a[i]==6)	six++;
		else if(a[i]==7)	seven++;
		else if(a[i]==8)	eight++;
		else if(a[i]==9)	nine++;
		else if(a[i]==10)	ten++;
		else continue;
	}
	printf(" %d %d %d %d %d %d %d %d %d %d",one,two,three,four,five,six,seven,eight,nine,ten);
}
int main(){ 
	char sentence[150];
	int length[150];
	int number=0;
	for(int i=0;i<150;i++){
		length[i]=0;
	}
	while(1){
		Initialize(sentence);
		gets(sentence);
		if(strcmp(sentence,"EOF.")!=0){
			number++;
			for(int i=0;sentence[i]!='#'&&sentence[i+1]!='#';i++){
				if(sentence[i]==' '||sentence[i]=='\t'){
					if(sentence[i+1]!=' '){
						number++;
					}
				}
				else if(sentence[i]==','||sentence[i]=='.'){
					if(sentence[i+1]!=' '&&sentence[i+1]!='"'&&sentence[i+1]!='('&&sentence[i+1]!=')'){
						number++;
					}
				}
				else if(sentence[i]=='?'||sentence[i]=='('||sentence[i]==')'){
					if(sentence[i+1]!=' '&&sentence[i+1]!='"'&&sentence[i+1]!='('&&sentence[i+1]!=')'){
						number++;
					}
				}
				else if(sentence[i]==':'||sentence[i]=='"'){
					if(sentence[i+1]!=' '&&sentence[i+1]!='"'){
						number++;
					}
				}
				else{
					length[number]++;
				}
			}
		}
		else{
			break;
		}
	}
	printf("%d",number-1);
	getNumber(length);
	return 0;
}
