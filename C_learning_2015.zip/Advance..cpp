#include <stdio.h>
#include <stdlib.h>

typedef struct _note{
	int value;
	struct _note* last;
}Note;

typedef struct _list{
	Note* head;
	Note* tail;
}List;

void add(List* plist,int input);

void print(List* plist); 

int main(int argc,const char* argv[]){
	List list;
	list.head=NULL;
	list.tail=NULL; 
	int number=0;
	do{
		scanf("%d",&number);
		if(number!=-1){
			add(&list,number);
		}
	}while(number!=-1);
	print(&list);
	return 0;
}

void add(List* plist,int input){
	Note* p=(Note*)malloc(sizeof(Note));
	p->value=input;
	p->last=NULL; 
	if(plist->tail){
		Note* pre= plist->tail;
//		plist->tail->last=pre;
//		plist->tail->value=p->value;
		plist->tail=p;
		plist->tail->last=pre;
	}else{
		plist->head=p; 
		plist->tail=plist->head;
	} 
}

void print(List* plist){
	for(Note* p=plist->tail;p;p=p->last){
		printf("%d ",p->value);
	}
}
