package Love;
import java.awt.*;
import javax.swing.*;

public class Image implements Icon{

	@Override
	public void paintIcon(Component c, Graphics g, int x, int y) {
		for(double i=0;true;i+=0.1){
			
		}
		
	}

	@Override
	public int getIconWidth() {
		return 0;
	}

	@Override
	public int getIconHeight() {
		// TODO 自动生成的方法存根
		return 0;
	}

}
