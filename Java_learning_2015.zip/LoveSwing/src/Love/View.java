package Love;
import java.awt.*;
import javax.swing.*;

public class View extends JFrame{
	public View(){
		Container container=getContentPane();
		URL heartImage=.class.getSource(heart.jpg);
		JButton begin=new JButton();
		container.add();
	}
	public static void main(String[] args){
		
	}
	
}
