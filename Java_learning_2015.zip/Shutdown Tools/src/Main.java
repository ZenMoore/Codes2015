import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.lang.reflect.*;
import java.awt.event.*;
public class Main extends JFrame{
	public Main(){
		Container container=this.getContentPane();
		container.setLayout(new GridLayout(4,4));
		
		final JButton[] jbs={new JButton("立即关机"),new JButton("定时间关机"),new JButton("定时刻关机"),
				new JButton("关闭所有应用"),new JButton("关机并重启"),new JButton("休眠"),new JButton("注销"),new JButton("拯救")};
		
		for(int i=0;i<jbs.length;i++){
			final int ii=i;
			jbs[i].addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
					try{
						Runtime.getRuntime().exec(System.getProperty("user.dir")+File.separator+jbs[ii].getText()+".bat");
					}catch(Exception ex){
						JOptionPane.showMessageDialog(null, ex.getMessage());
					}
				}
			});
		}
			
		for(int j=0;j<jbs.length;j++){
			container.add(jbs[j]);
		}
		this.setTitle("Shutdown Tools");
		this.setBounds(300, 300,300, 200);
		this.setBackground(Color.GRAY);
		this.setVisible(true);
		this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		new Main();

	}

}
