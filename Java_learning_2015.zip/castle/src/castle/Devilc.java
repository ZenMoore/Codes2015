package castle;

public class Devilc extends Devils{
	public Devilc(Game game) {
		super(game);
		name="万能的翔王：没错，我就是你！"+game.getAdmin()+"！多年前肚子里跑出的孩子！";
		attack=3;
 }
}
