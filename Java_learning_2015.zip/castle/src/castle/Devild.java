package castle;

public class Devild extends Devils{
	public Devild(Game game) {
		super(game);
		name="帅气的开发者（Boss）：1057398161，也许，你加了这个qq之后才能打败我!";
		attack=5;
 }
}
