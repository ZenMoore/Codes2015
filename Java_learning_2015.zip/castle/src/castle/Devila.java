package castle;

public class Devila extends Devils{

	public Devila(Game game) {
		super(game);
		name="机智的狗蛋儿：来吧,"+game.getAdmin()+",我就是狗蛋儿！";
		attack=1;
	}
}
	
