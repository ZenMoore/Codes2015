package castle;

public class Devilb extends  Devils{
	
	public Devilb(Game game) {
		super(game);
		name="疯狂的女汉子：呜呜，你个"+game.getAdmin()+"竟然不爱我了！";
		attack=2;
	
 }
	}
