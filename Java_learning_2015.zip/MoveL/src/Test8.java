
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
public class Test8 extends JFrame{
 public Test8(){
  this.setContentPane(new MyPanel());
  this.setLocation(200,200);
  this.setSize(400, 260);
  this.setVisible(true);
  this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 }
 public static void main(String[] args) {
  new Test8();
 }
}
class MyPanel extends JPanel{
 JButton jbStart = null;
 public MyPanel(){
  init();
  this.setLocation(200,200);
  this.setSize(400, 260);
 }
 private void init() {
  jbStart = new JButton("开始");
  this.setLayout(null);
  jbStart.setBounds(50, 180, 60, 35);
  jbStart.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e) {
    Timer timer = new Timer();
    //设置定时器的任务
    timer.schedule(new TimerTask(){
     int i = -200;
     @Override
     public void run() {
      paint(MyPanel.this.getGraphics());
//      一个周期
      MyPanel.this.myPaint(new Point(i,100));
//      两个周期
      MyPanel.this.myPaint(new Point(i+200,100));
//      三个周期
      MyPanel.this.myPaint(new Point(i+400,100));
      //i+=2一次移动两个坐标，越大每次移动的越远
      i+=2;
      if(i>0){
       i=-200;
      }
     }
     
    }, 0 , 100);//100是0.1秒一到一次，越小动的越快
    jbStart.setVisible(false);
   }
   
  });
  add(jbStart);
 }
 //画图
 private void myPaint(Point point) {
  List<Point> points = getPoint(point);
  for (int i= 0;i<points.size()-1;i++) {
   //画线
   this.getGraphics().drawLine((int)points.get(i).getX(), (int)points.get(i).getY(), (int)points.get(i+1).getX(), (int)points.get(i+1).getY());
  }
 
 }
//获取一个周期图形的个个点的坐标
 private List<Point> getPoint(Point p) {
  List<Point> list =new ArrayList<Point>();
  Point p2 = new Point((int)p.getX(),(int)p.getY()-30);
  Point p3 = new Point((int)p2.getX()+60,(int)p2.getY());
  Point p4 = new Point((int)p3.getX(),(int)p3.getY()+30);
  Point p5 = new Point((int)p4.getX()+20,(int)p4.getY());
  Point p6 = new Point((int)p5.getX(),(int)p5.getY()-30);
  Point p7 = new Point((int)p6.getX()+60,(int)p6.getY());
  Point p8 = new Point((int)p7.getX(),(int)p7.getY()+30);
  Point p9 = new Point((int)p8.getX()+60,(int)p8.getY());
  list.add(p);
  list.add(p2);
  list.add(p3);
  list.add(p4);
  list.add(p5);
  list.add(p6);
  list.add(p7);
  list.add(p8);
  list.add(p9);
  return list;
 }
}