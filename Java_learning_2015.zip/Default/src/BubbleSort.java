import java.util.Scanner;
public class BubbleSort {

	public static void BubbleSort(int[] Array,int Lenth)
	{
		int i,j,temp;
		for (i=0;i<Lenth;i++)
			for (j=0;j<Lenth-1;j++)
				 if (Array[j]>Array[j+1])
					 {
					 temp = Array[j];
					 Array[j] = Array[j+1];
					 Array[j+1] = temp;
					 }    
	}
	public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int[] Array = new int[n];
        for (int i=0;i<n;i++)
        	Array[i] = in.nextInt();
        BubbleSort(Array,n);
        for (int k:Array)
        	System.out.print(k + " ");
        in.close();
	}

}