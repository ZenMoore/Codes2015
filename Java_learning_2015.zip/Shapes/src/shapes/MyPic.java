package shapes;

public class MyPic {
	public static void main(String[] args) 
	{
		Picture pic =new Picture(500,500);	
		Circle c1=new Circle(250,250,10);
		Circle c2=new Circle(250,250,20);
		Circle c3=new Circle(250,250,30);
		Circle c4=new Circle(250,250,40);
		Circle c5=new Circle(250,250,50);
		Circle c6=new Circle(250,250,60);
		Circle c7=new Circle(250,250,70);
		Circle c8=new Circle(250,250,80);
		Circle c9=new Circle(250,250,90);
		Circle c10=new Circle(250,250,100);
		Circle c11=new Circle(250,250,110);
		pic.add(c1);
		pic.add(c2);
		pic.add(c3);
		pic.add(c4);
		pic.add(c5);
		pic.add(c6);
		pic.add(c7);
		pic.add(c8);
		pic.add(c9);
		pic.add(c10);
		pic.add(c11);
		pic.draw();
	}
}
