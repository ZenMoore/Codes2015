import java.util.Scanner;
public class Main {
	private int width;
	private int height;
	private boolean[][] net;
	private int step; 
	private Scanner in=new Scanner(System.in);
	
	public void createNet(){
		this.net=new boolean[width][height];
	}

	public void setSize(){
		while(true){
			this.width=in.nextInt();
			this.height=in.nextInt();
			if(width<3||width>102||height<3||height>102){
				continue;
			}else{
				break;
			}
		}
	}
	
	public void setCell(){
		while(true){
			int y=in.nextInt();
			int x=in.nextInt();
			if(x==-1||y==-1){
				break;
			}
			this.net[x][y]=true;
		}
	}
	
	public void setStep(){
		this.step=in.nextInt();
		in.close();
	}
	
	public void setDie(int x,int y){
		net[x][y]=false;
	}
	
	public void setAlive(int  x,int y){
		net[x][y]=true;
	}
	
	public void check(){
		for(int i=0;i<net.length;i++){
			for(int j=0;j<net[i].length;j++){
				int number=0;
				int k=i-1;
				int l=j-1;
				int count=0;
				while(count<8){
					count++;
					if(!(k==-1||l==-1||k==this.width||l==this.height)){
						if(net[k][l]==true){
							number++;
						}
					}
					if(count<3){
						k++;
					}else if(count==3){
						k=i-1;
						l=j;
					}else if(count>3&&count<5){
						k=i+1;
					}else if(count==5){
						k=i-1;
						l=j+1;
					}else if(count>5){
						k++;
					}else{}	
				}
				if(number==2||number==3){
					this.setAlive(i, j);
				}else{
					this.setDie(i, j);
				}
			}
		}
	}
	
	public int getResult(){
		int result=0;
		for(int i=0;i<net.length;i++){
			for(int j=0;j<net[i].length;j++){
				if(net[i][j]==true){
					result++;
				}
			}
		}
		return result;
	}
	
	public void play(){ 
		this.setSize();
		this.createNet();
		this.setCell();
		this.setStep();
		for(int count=0;count<this.step;count++){
			this.check();
		}
		System.out.println(this.getResult());
	}
	public static void main(String[] args) {
		// TODO 自动生成的方法存根
		new Main().play();
	}

}
