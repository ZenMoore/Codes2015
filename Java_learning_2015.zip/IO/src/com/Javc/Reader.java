package com.Javc;
import java.io.*;
public class Reader {
	public static void main(String[] args){
		byte[] byt="你是谁呢，我想知道".getBytes();
		try{
			File file=new File("E:/text.txt");
			if(!file.exists()){
				file.createNewFile();
			}
			FileOutputStream out=new FileOutputStream(file);
			for(int i=0;i<byt.length;i++){
				byt[i]++;
			}
			out.write(byt);
			FileInputStream in=new FileInputStream(file);
			File nfile=new File("E:/nText.txt");
			if(!nfile.exists()){
				nfile.createNewFile();
			}
			out=new FileOutputStream(nfile);
			byte temp;
			while((temp=(byte)in.read())!=-1){
				temp--;
				out.write(temp);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
