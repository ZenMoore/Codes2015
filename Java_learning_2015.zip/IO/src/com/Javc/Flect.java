package com.Javc;
import java.lang.reflect.*;
public class Flect {
	public static void main(String[] args){
		System.out.println(4624>>10);
	}
}
