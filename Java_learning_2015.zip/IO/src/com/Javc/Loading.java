package com.Javc;
import javax.swing.*;
import java.io.*;
public class Loading{
	private static File currentFile; 
	public static void doit(File file){
		try{
			ProgressMonitorInputStream pro=new ProgressMonitorInputStream(null,"Loading...",new FileInputStream(file));
			byte data[]=new byte[2];
			while(pro.read(data)!=-1){
				System.out.print(new String(data));
				Thread.sleep(100);
			}
		}catch(InterruptedIOException e){
			new JOptionPane().showMessageDialog(null, "Stopped!");
		}catch(Exception e){
			new JOptionPane().showMessageDialog(null, e.getMessage());
		}	
	}

	public static void check(File file){
		if(file.isDirectory()){
			for(File f:file.listFiles()){
				Loading.check(f);
			}
		}else{
			currentFile=file;
		}
	}
	
	public static void main(String[] args){
		File file=new File("E:/L");
		Loading.check(file);
		Loading.doit(currentFile);
	}
}
