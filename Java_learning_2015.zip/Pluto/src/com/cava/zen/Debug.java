package com.cava.zen;

public class Debug {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String arc="Imyoung.";
		System.out.println(arc.substring(1, 2));
		try{
			Thread.sleep(1000);
			System.out.println("000");
		}catch(Exception e){
			
		}
	}

}
