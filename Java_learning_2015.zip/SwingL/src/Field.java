import java.awt.*;
import java.util.Vector;
import java.net.URL;
import javax.swing.*;
import java.awt.event.*;
import java.awt.event.*;

public class Field extends JFrame {
	public Field(){
		Container container=getContentPane();
		container.setLayout(new BorderLayout());
		
//		Vector vector=new Vector();
//		JList<String> jl=new JList<String>(vector);
//		vector.addElement("s");
//		vector.add("ddddd");
//		JScrollPane js=new JScrollPane(jl);
//		js.setBounds(2, 2, 50, 50);
//		container.add(js);
		
//		URL url=JComboBoxModelTest.class.getResource("image.jpg");
//		Icon icon=new ImageIcon(url);
//		JLabel jlb=new JLabel(icon);
//		jlb.setBounds(60, 60, 20, 20);
//		container.add(jlb);
		
//		final JPasswordField jp=new JPasswordField("JTextField.",100);
//		jp.setEchoChar('^');
//		final JButton delete=new JButton("Delete");
//		final JButton replace=new JButton("Replace");
//		jp.addActionListener(new ActionListener(){
//			public void actionPerformed(ActionEvent e){
//				new MyDialog(Field.this);
//			}
//		});
//		delete.addActionListener(new ActionListener(){
//			public void actionPerformed(ActionEvent arg0){
//				jp.setText("");
//			}
//		});
//		replace.addActionListener(new ActionListener(){
//			public void actionPerformed(ActionEvent e){
//				jp.setText("Replaced.");
//			}
//		});
//		container.add(BorderLayout.EAST,delete);
//		container.add(BorderLayout.NORTH,replace);container.add(BorderLayout.WEST,jp);
		
//		JTextArea jta=new JTextArea("Text Area.",55,55);
//		jta.setLineWrap(true);
//		jta.setBounds(0, 0	, 80, 80);
//		JButton jb=new JButton("Complete");
//		jb.setBounds(50, 10, 30, 30);
//		jb.addActionListener(new Yo(this));
//		container.add(jta);
//		container.add(jb);
		
		final JTextArea jta=new JTextArea("Experience.",30,30);
		jta.addFocusListener(new FocusListener(){
			@Override
			public void focusLost(FocusEvent e){
				JOptionPane.showMessageDialog(null,"LOST!");
				jta.requestFocus();
			}
			
			@Override
			public void focusGained(FocusEvent e){
			}
		});
		container.add(jta);
		setBounds(300,300,300,300);
		setVisible(true);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
	public static void main(String[] args) {
		new Field();
	}
}

class MyDialog extends JDialog{
	public MyDialog(Field field,String str){
		super(field,"JDialog",true);
		Container container=getContentPane();
		container.add(new JLabel(str));
		setBounds(20,20,200,200);
	}
}

class Yo implements ActionListener{
	Field ff;
	
	Yo(Field ff){
		this.ff=ff;
	}

	public void actionPerformed(ActionEvent e){
			new MyDialog(ff,"Congratulations!").setVisible(true);
		}
}
