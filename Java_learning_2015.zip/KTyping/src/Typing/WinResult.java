package Typing;

public interface WinResult {
	public void winCreate();
}
