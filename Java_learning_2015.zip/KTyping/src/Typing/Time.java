package Typing;

public class Time {
	private static long beginTime;
	private static long endTime;
	public static void setBeginTime(){
		beginTime=System.currentTimeMillis();
	}
	public static void setEndTime(){
		endTime=System.currentTimeMillis();
	}
	public static long getTime(){
		return endTime-beginTime;
	}
}
