package Typing;
import java.awt.*;
import javax.swing.*;

import Typing.Choice;

import java.awt.event.*;
import java.util.*;
public class Choice extends JFrame{
	private static JFrame frame=new JFrame();
	
	public Choice(){
		Container container=frame.getContentPane();
		container.setLayout(new GridLayout(2,1));
		
		Data.setSimpleData();
		final JComboBox chooses=new JComboBox(Data.getSimpleKey());
	
		JButton yes=new JButton("确定");
		yes.addActionListener(new ActionListener(){
			@Override 
			public void actionPerformed(ActionEvent e){
				frame.setEnabled(false);
				new IME((Integer)chooses.getSelectedItem());
			}
		});
		JPanel jp=new JPanel();jp.add(chooses);jp.add(yes);
		
		container.add(new JLabel("困难度选择："));
		container.add(jp);
		
		frame.setTitle("选择");
		frame.setBounds(400,400,200,130);
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		frame.setBackground(Color.blue);
		frame.setVisible(true);
	}
	
	public static void setEn(){
		frame.setEnabled(true);
	}
	public static void main(String[] args){
		new Choice();
	}
	
	


}
