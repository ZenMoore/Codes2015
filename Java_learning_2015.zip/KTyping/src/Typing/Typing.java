package Typing;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Typing extends JDialog {
	public Typing(Integer choose){
		Container container=getContentPane();
		
		JPanel jp2=new JPanel();
		jp2.setLayout(new GridLayout(2,1));
		final JTextArea exam=new JTextArea(Data.getSimpleData(choose),100,100);
		exam.setLineWrap(true);
		exam.setFocusable(false);
		JScrollPane above=new JScrollPane(exam);
		jp2.add(above);
		final JTextArea in=new JTextArea(100,100);
		in.setLineWrap(true);
		in.setFocusable(false);
		JScrollPane below=new JScrollPane(in);
		jp2.add(below);
		
		final JButton begin=new JButton("开始");
		final JButton end=new JButton("结束");
		end.setEnabled(false);
		begin.addActionListener(new ActionListener(){
			@Override 
			public void actionPerformed(ActionEvent e){
				begin.setEnabled(false);
				in.setFocusable(true);
				in.requestFocus();
				end.setEnabled(true);
				Time.setBeginTime();
			}
		});
		end.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){
				in.setEnabled(false);
				Time.setEndTime();
				new Result(in.getText(),exam.getText());
				Typing.this.dispose();
			}
		});
		JPanel jp=new JPanel();
		jp.add(begin);jp.add(end);
		
		JLabel jl=new JLabel("请不要输入标点");
		jl.setForeground(Color.RED);
		container.add(BorderLayout.NORTH,jl);
		container.add(jp2);
		container.add(BorderLayout.SOUTH, jp);
		
		setTitle("测试");
		setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		setBounds(400,400,400,300);
		setVisible(true);
	}
}
