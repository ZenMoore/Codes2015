package Typing;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.plaf.DimensionUIResource;
public class IME extends JDialog{
	public IME(final Integer choose){
		Container container=getContentPane();
		container.add(BorderLayout.CENTER,new JLabel("请自行切换至韩文输入法。"));
		JButton yes=new JButton("完成");
		yes.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){
				new Typing(choose);
				IME.this.dispose();
			}
		});
		container.add(BorderLayout.SOUTH,yes);
		
		setTitle("输入法");
		setAlwaysOnTop(true);
		setBounds(400,400,200,150);
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		setVisible(true);
		setBackground(Color.blue);
	}
}
