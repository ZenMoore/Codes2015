package Typing;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.WindowConstants;

public class Result extends JDialog implements FailResult,WinResult{
	private JButton yes=new JButton("我知道了。");
	private Container container=getContentPane();

	public Result(String input,String should){
		input=input.trim();
		input=input.replaceAll("\\s+","");
		input=input.replaceAll("\n","");
		if(input.equals(should)){
			winCreate();
		}else{
			failCreate();
		}
		container.add(BorderLayout.SOUTH,yes);
		
		setBackground(Color.orange);
		setBounds(200,200,250,150);
		setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		setVisible(true);
	}
	
	@Override
	public void failCreate(){
		yes.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){
				Choice.setEn();
				Result.this.dispose();
			}
	});		
	container.add(BorderLayout.NORTH,new JLabel("失败，您输入有错误，用时： "+(int)Time.getTime()/1000+"秒"));
	}
	
	@Override
	public  void winCreate(){
		yes.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){
				Choice.setEn();
				Result.this.dispose();
			}
	});
		
	container.add(BorderLayout.NORTH,new JLabel("成功，您输入正确，用时： "+(int)Time.getTime()/1000+"秒"));
	}
}





	