package Typing;

public interface FailResult {
	public void failCreate();
}
