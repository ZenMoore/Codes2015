package Typing;
import java.util.*;
public class Data {
	private static final HashMap<Integer,String> simple=new HashMap<Integer,String>();
	
	public static Integer[] getSimpleKey(){
		Integer[] intd=new Integer[simple.keySet().size()];
		int i=0;
		for(Integer ind:simple.keySet()){
			intd[i++]=i;
		}
		return intd;
	}
	
 	public static void setSimpleData(){
		simple.put(1,"신기한현상이다");
		simple.put(2,"왜한국사람은골프에미칠까");
		simple.put(3,"고스톱처럼내기골프도이런저런반전의장치를만들었다");
		simple.put(4,"아무튼며칠전약간쌀쌀한날씨에짙은안개가자욱했던어느날");
		simple.put(5,"한국인에게골프의유전자가있는것이아니라골프에고스톱의유전자가있는셈인가");
		simple.put(6,"세계어디에서든비바람이불고눈이오는날골프장에서누군가를만났다면한국사람일가능성이크다");
		simple.put(7,"오늘은그러는의미에서며칠남지않은설날을준비하는중국사람들의이모저모를카메라에담아보았습니다");
		simple.put(8,"북경은최근안개인지매연인지모를정도로공기가상당히나빠진것같습니다원래북경은겨울철만되면바람이강하게불어와");
		simple.put(9,"중국은땅도넓고인구도많아설날의대이동은그다지쉽지는않습니다고향으로내려가는교통편을알아보기위해열흘전심지어는한달전부터미리서둘러야합니다");
	}
	
	public static String getSimpleData(int choice){
		return simple.get(choice);
	}
}
