import java.awt.Graphics;

/**
 * 屏幕上的球类。实现了<code>Base</code>接口，所以可以当作底座使用<br/>
 * 使用正常坐标系. x，y是园心坐标
 * @author 梦
 */
public class Ball implements Base,Drawable{
	private double x;
	private double y;
	private double r;
	private double speed;
	private Direction dir;
	
	
	/**
	 * 根据现有的方向和速率数据来进行一次移动
	 */
	public void move(){
		x+=dir.getDeltaX(speed);
		y+=dir.getDeltaY(speed);
	}
	
	public void setSpeed(double i) {
		speed = i;
	}
	
	public Ball(double x, double y, double r, Direction dir) {
		super();
		this.x = x;
		this.y = y;
		this.r = r;
		this.dir = dir;
	}
	public double getX() {
		return x;
	}
	public void setX(double x) {
		this.x = x;
	}
	public double getY() {
		return y;
	}
	public void setY(double y) {
		this.y = y;
	}
	public double getR() {
		return r;
	}
	public void setR(double r) {
		this.r = r;
	}
	public Direction getDirection() {
		return dir;
	}

	public void setDirection(Direction dir){
		this.dir = dir;
	}

	//TODO 注意这个函数是存在错误的！！！！这是需要修改的！！！！水平有限，望各位代为改正！！！！
	@Override
	public boolean meet(Ball ball) {		
		double a = ball.y - this.y;
		double b = ball.x - this.x;
		if( Math.abs(Math.sqrt(a*a+b*b) - ball.r - this.r) < 1){
			ball.dir.change(Math.PI-Math.atan(b/a));
			System.out.println("Ball.meet()  dirchanged");
			return true;
		}
		return false;
	}

	@Override
	public void draw(Graphics graphics, CoordinateConverter converter) {
		graphics.drawOval((int)(converter.getScreenX(x-r)), (int)(converter.getScreenY(y+r)), 
				(int)converter.getScreenWidth(2*r), (int)converter.getScreenHeight(2*r));
	}
}
