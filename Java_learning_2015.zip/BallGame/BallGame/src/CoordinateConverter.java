
/**
 * <p>
 * 坐标转换器。用于将一个普通的平面直角坐标系中的坐标转换为屏幕坐标</br>
 * 可以实现横向和纵向的分别拉伸和压缩，坐标系的平移。
 * 类中大部分代码是Eclipse自动生成的
 * </p>
 * <p>
 * 在这个程序里面,除了世纪在屏幕上画图的时候，使用的都是非屏幕坐标系。画图的时候用这个类来转化
 * </p>
 * @author 梦
 *
 */

public class CoordinateConverter {
	private double screenWidth;
	private double screenHeight;
	private double screenOriginX;
	private double screenOriginY;
	
	private double graphicsWidth;
	private double graphicsHeight;
	private double graphicsOriginX;
	private double graphicsOriginY;
	
	public CoordinateConverter(double screenWidth, double screenHeight,
			double screenOriginX, double screenOriginY, double graphicsWidth,
			double graphicsHeight, double graphicsOriginX,
			double graphicsOriginY) {
		this.screenWidth = screenWidth;
		this.screenHeight = screenHeight;
		this.screenOriginX = screenOriginX;
		this.screenOriginY = screenOriginY;
		this.graphicsWidth = graphicsWidth;
		this.graphicsHeight = graphicsHeight;
		this.graphicsOriginX = graphicsOriginX;
		this.graphicsOriginY = graphicsOriginY;	
	}
	
	public CoordinateConverter(double screenWidth, double screenHeight,
			double screenOriginX, double screenOriginY, double graphicsWidth,
			double graphicsHeight) {
			this(screenWidth, screenHeight,screenOriginX,
				screenOriginY, graphicsWidth,graphicsHeight,0,0);
	}
	
	public CoordinateConverter(double screenWidth, double screenHeight,
			double screenOriginX, double screenOriginY) {
			this(screenWidth, screenHeight,screenOriginX,
				screenOriginY, screenWidth,screenHeight,0,0);
	}
	
	public CoordinateConverter(double screenWidth, double screenHeight) {
			this(screenWidth, screenHeight,0,
				0, screenWidth,screenHeight,0,0);
	}
	
	
	/**
	 * 根据一个图像上的坐标的X值来获取屏幕上实际的X
	 * @param x 图像上的x
	 * @return 实际的x
	 */
	public double getScreenX(double x){
		return screenOriginX+(graphicsOriginX+x)*screenWidth/graphicsWidth;
	}
	
	/**
	 * 同 <code>CoordinateConverter::getScreenX(double x)</code>
	 * @param y
	 * @return
	 */
	public double getScreenY(double y){
		return screenOriginY+(screenHeight-graphicsOriginY-y)*screenHeight/graphicsHeight;
	}
	
	/**
	 * 根据图像宽度获取屏幕宽度
	 * @param width
	 * @return
	 */
	public double getScreenWidth(double width){
		return screenWidth*width/graphicsWidth;
	}
	
	/**
	 * 根据图像高度获取屏幕高度
	 * @param height
	 * @return
	 */
	public double getScreenHeight(double height){
		return screenHeight*height/graphicsHeight;
	}
	
}
