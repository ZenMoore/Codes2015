import java.awt.Graphics;

/**
 * <code>GameOutput</code>所接受的对象。实现<code>Drawable</code>方法的对象都可以被绘制
 * @author 梦
 *
 */
public interface Drawable {
	/**
	 * 将自己绘制到<code>Graphics</code>中去。
	 * @param graphics 将要绘制的<code>Graphics</code>对象
	 * @param converter 坐标转换器
	 */
	public void draw(Graphics graphics, CoordinateConverter converter);

}
