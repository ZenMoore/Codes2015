import java.awt.Graphics;
import java.util.HashSet;
import java.util.Set;

import static java.lang.Math.PI;;


/**
 * 使用正常坐标系 </br>
 * x,y是砖块左下角的坐标
 * @author 梦
 */

public class Brick implements Drawable{
	private double x;
	private double y;
	private double width;
	private double height;
	
	public Brick(double x, double y, double width, double height) {
		super();
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}
	
	public Brick(){}

	/**
	 * 如果遇到这个球，则返回<code>true</code>,并且改变这个球的运动方向 <br/>
	 * 否则返回<code>false</code> </br>
	 * <i>关于下面这个方法的物理上的正确性，可以在草稿纸上作图验证</i><br/>
	 * @param b 来判断的球
	 * @return 是否遇到
	 */
	public boolean meet(Ball b){
		
		/**
		 * 先判断是否遇到了这个球
		 */
		if(b.getY()-b.getR()<=
				y+height && b.getY()+b.getR() >= y &&
				b.getX()+b.getR() >= x && b.getX()-b.getR() <= x+width){

			/**
			 * 下面是判断球遇到了砖块的那个面
			 */
			double h = y+height - b.getY()-b.getR();
			if(b.getY()+b.getR() - (y) < h) h = b.getY()+b.getR() - (y);
			
			double v = b.getX()+b.getR() - x;
			if(x+width - (b.getX()-b.getR()) < v) v = x+width - (b.getX()-b.getR());
			
			/**
			 * 根据情况改变球的运动方向
			 */
			if(h > v){
				b.getDirection().change(0);;
			}else if( h <= v){
				b.getDirection().change(PI/2);
			}
			
			return true;
		}
		return false;
	}
	
	
	//TODO 除了这个方法，有更多的方法待添加。比如fromFile().具体方法是序列化和反序列化一个Brick的集和或数组
	/**
	 * 将布尔量数组转化为<code>Brick</code>集和。<code>true</code>代表有，<code>false</code>代表没有<br/>
	 * 使用正常的平面直角坐标系<i>(而不是通常的计算机屏幕坐标系)</i><br/>
	 * 这个方法的主要作用是开发阶段的调试
	 * @param sources 布尔值数组。注意需要严格的二维数组，而不是“数组的数组”
	 * @param x 左下角横坐标
	 * @param y 左下角纵坐标
	 * @param width 宽度
	 * @param height 高度
	 * @return 一个转换后的<code>HashSet</code>
	 * 
	 */
	public static Set<Brick> fromBooleanArray(boolean[][] sources,double x,
			double y, double width, double height){
		
		final double space = 0.2;
		
		int rows = sources.length;
		int cols = sources[0].length;
		
		double blockHeight = height/rows;
		double blockWidth = width/cols;
		
		double brickHeight = blockHeight*(1-space);
		double brickWidth = blockWidth*(1-space);
		
		double hSpace = blockWidth * (space/2);
		double vSpace = blockHeight * (space/2);
		
		Set<Brick> bricks = new HashSet<Brick>();
		for(int i = 0; i < rows; i++){
			for(int j = 0; j < cols; j++){
				Brick brick = new Brick();
				brick.x = x + j*blockWidth + hSpace;
				brick.y = y + i*blockHeight + vSpace;
				brick.width = brickWidth;
				brick.height = brickHeight;
				System.out.println(brick);
				bricks.add(brick);
			}
		}
		
		return bricks;
	}
	
	public double getX(){
		return x;
	}
	public double getY(){
		return y;
	}
	public double getWidth(){
		return width;
	}
	public double getHeight(){
		return height;
	}

	@Override
	public String toString() {
		return "Brick [x=" + x + ", y=" + y + ", width=" + width + ", height="
				+ height + "]";
	}
	
	@Override
	public void draw(Graphics graphics, CoordinateConverter converter) {
		graphics.drawRect((int)converter.getScreenX(x),(int)converter.getScreenY(y+height),
				(int)converter.getScreenWidth(width),(int)converter.getScreenHeight(height));
	}
	
	
	/**
	 * 实现下面两个方法纯粹是给HashSet用，内容也是Eclipse自动生成的，请无视
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(height);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(width);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(x);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(y);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Brick other = (Brick) obj;
		if (Double.doubleToLongBits(height) != Double
				.doubleToLongBits(other.height))
			return false;
		if (Double.doubleToLongBits(width) != Double
				.doubleToLongBits(other.width))
			return false;
		if (Double.doubleToLongBits(x) != Double.doubleToLongBits(other.x))
			return false;
		if (Double.doubleToLongBits(y) != Double.doubleToLongBits(other.y))
			return false;
		return true;
	}
	
}
