/**
 * 底座接口，使用正常坐标
 * @author frank
 *
 */

public interface Base extends Drawable{
	
	/**
	 * 如果没有遇到这个<code>Ball</code>,返回<code>false</code>;
	 * 如果有,返回<code>true</code>,并改变该球运动方向
	 * @param b 要判断的<code>Ball</code>
	 * 
	 * @author 梦
	 */
	boolean meet(Ball b);

	double getX();
	double getY();
	double getR();
	
	void setDirection(Direction dir);

	void setSpeed(double i);

	void move();
}
