
/**
 * 下图是我们使用的坐标系
 * 直接看源代码（而不是Javadoc）<br/><br/><br/><br/>
 * 
 *  y
 *  ^                     --|   
 *  |               PI/2  /    direction
 *  |                ^   /
 *  |                |  /
 *  |                | /
 *  |                |/\  theta
 *  |      ---------------------> 0 
 *  |                |
 *  |                |
 *  |                |
 *  |
 *  ------------------------------------>  x
 * 
 * @author 梦
 * */


public class Direction {
	private double theta;
	Direction(double theta){
		this.theta = theta;
	}
	public void setDirection(double theta){
		this.theta = theta;
	}
	public void setDirection(Direction dir){
		setDirection(dir.theta);
	}
	public double getDirection(){
		return this.theta;
	}
	public double getDeltaX(double r){
		return r*Math.cos(theta);
	}
	public double getDeltaY(double r){
		return r*Math.sin(theta);
	}
	public double getTheta(){
		return theta;
	}
	/**
	 * 参数dir是镜面角度，将自己作为入射光线，将自己的角度改变为反射光线的角度
	 * @param dir
	 */
	public void change(Direction dir){
		change(dir.getTheta());
	}
	
	/**
	 * 参数theta是镜面角度，将自己作为入射光线，将自己的角度改变为反射光线的角度
	 * @param theta
	 */
	public void change(double theta){
		this.theta = Math.PI+2*theta-this.theta;
	}
}
