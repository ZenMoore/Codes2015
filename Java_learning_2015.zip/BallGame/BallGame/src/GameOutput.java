import java.util.Set;
/**
 * 游戏输出器，主要是屏幕。当然就这个游戏来说，终端输出应该也是可以实现的，有待各位添加<br/>
 * 设计这么一个接口的另外目的是可以用不同的方法在屏幕上输出。不同的方法在不同的机器上会有不同的效率</br>
 * 游戏设计过程中输出类<code>GameBoard</code>就多次遇到卡顿，闪烁等问题。设计这个接口给这个问题的灵活解决提供了渠道
 * @author 梦
 */

public interface GameOutput {
	int getWidth();
	int getHeight();
	void draw(Set<Drawable> s);
}
