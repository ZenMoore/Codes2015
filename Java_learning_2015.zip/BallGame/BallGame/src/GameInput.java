/**
 * 游戏输入器。他的子类可以从如键盘，鼠标，网络，游戏手柄来获得。
 * @author 梦
 *
 */
public interface GameInput {
	void setInputListener(InputListener listener);
}
