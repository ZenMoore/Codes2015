import java.util.HashSet;
import java.util.Set;

/**
 * <code>GameController</code>是整个的核心类，这个类实现了主要逻辑（MVC中的C层）<br/>
 * 这个类的使用方法是简单的，只需要<code>new GameController()</code>即可。<br/>
 * <code>Main::main(String [] args)</code>仅仅是一个入口，主要的逻辑都在这个类里面 <br/>
 * @author 梦
 *
 */

public class GameController implements InputListener{
	
	/**
	 * 这是用于MVC中V层和C层交互用的数据
	 * 或者说，是某种意义上的M层
	 */
	private Set<Brick> bricks;
	private Set<Ball> balls;
	private Base base;
	private Set<Brick> walls;
	private Brick flow;
	
	/**
	 * 这是用于游戏的输入器和输出器，目前事实上的输入器和输出器都是GameBoard类
	 */
	private GameOutput output;
	private GameInput input;

	
	
	/**
	 * 构造方法，也是主要逻辑所在的地方
	 */
	GameController(){

		/** 初始化输入器和输出器 */
		output = new GameBoard(10,10,400,400);
		input = (GameInput) output;
		input.setInputListener(this);
		
		/** 使用砖块当作墙面，也不知是好是坏 */
		walls = new HashSet<Brick>();
		Brick b1 = new Brick(-10,-10,10,410);
		Brick b2 = new Brick(-10,400,400,10);
		Brick b3 = new Brick(400, -10, 10, 410);
		walls.add(b1);
		walls.add(b2);
		walls.add(b3);
		flow = new Brick(-10, -10, 420, 10);
		
		
		/**
		 * 屏幕上可以同时出现多个球，这里只放了一个，需要的话可以添加。
		 * 考虑到效率一般控制在5个以内 
		 */
		balls = new HashSet<Ball>();
		Ball b11 = new Ball(200,200,15,new Direction(5));
		b11.setSpeed(1);
		balls.add(b11);

		
		/**
		 * 添加砖块。这里使用的是fromBooleanArray方法。该方法详细介绍见Brick类。
		 */
		bricks = Brick.fromBooleanArray(new boolean[][]{
				{true,true,true,true},
				{true,false,true,true},
				{true,true,true,true},
				{true,true,true,true}
		}, 0, 0, output.getWidth(), output.getHeight());
		
		/** 设置底座。底座只有一个。Ball实现了Base接口 */
		base = new Ball(200,0,50,new Direction(1));
		
		/** 在输出设备上画出来 */
		Set<Drawable> s = new HashSet<Drawable>();
		s.addAll(bricks);
		s.addAll(balls);
		s.add(base);
		output.draw(s);
		
		new Thread(()->{
			
			/**
			 * 这是在另外一个线程里面，主要实现每一贞的物体的移动
			 * 是一个死循环
			 */

			while(true){
				/** 我们允许一个屏幕上有多个球存在，这里就是对每个球进行判断 */
				for(Ball b : balls){
					
					/** 如果球碰到地板(但愿我没有拼错单词),那么游戏结束。更合理的方法是弹窗提示 */
					//TODO 弹窗提示
					if(flow.meet(b))System.out.println("Game Over!");
					
					/** 如果球遇到墙面就反弹 */
					for(Brick wall : walls){
						wall.meet(b);
					}
					
					/** 如果球遇到砖块，那么球反弹，砖块消失 */
					Set<Brick> rm = new HashSet<Brick>();
					for(Brick brick : bricks){
						if(brick.meet(b))rm.add(brick);
					}
					bricks.removeAll(rm);
					b.move();
					
					/**如果球遇到底座，球反弹*/
					base.meet(b);
					System.out.println("x:"+base.getX());
					//System.out.println("GameController.GameController() base.move");
					base.move();
					
					
					/** 调用输出器来输出内容 */ //TODO Drawable
					Set<Drawable> set = new HashSet<Drawable>();
					set.addAll(bricks);
					set.addAll(balls);
					set.add(base);
					output.draw(set);
					
					
				}
				
				/**
				 * 休息20毫秒。
				 */
				try {
					Thread.sleep(20);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
		}).start();
		
		
	}
	
	
	public static void main(String[] args) {
		new GameController();
	}
	

	@Override
	public void move(Direction dir, Status status) {
//		System.out.println("GameController.move()");
		if(status == Status.start){
			base.setDirection(dir);
			base.setSpeed(10);
		}else {
			base.setDirection(dir);
			base.setSpeed(0);
		}
	}
	
}
