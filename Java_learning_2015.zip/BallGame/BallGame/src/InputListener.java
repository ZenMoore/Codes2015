/**
 * GameInput接口要求它的实现类都实现<code>setInputListener</code>方法<br/>
 * <code>InputListener</code>接口又有<code>move(...)</code>方法<br/>
 * 也就是当<code>GameInput</code>接受到他认为的合适事件的时候，就调用<code>InputListener</code>
 * 的<code>move(...)</code>方法
 * @author 梦
 *
 */


public interface InputListener {
	enum Status{start,stop};
	
	/**
	 * 监测到底座需要移动的事件的时候该方法会被自动调用
	 * @param dir 方向
	 * @param status 状态，是开始还是停止
	 */
	void move(Direction dir,Status status);
}
