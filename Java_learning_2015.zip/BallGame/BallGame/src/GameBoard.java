import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.util.Set;

import javax.swing.JFrame;

/**
 * <code>GameBoard</code>实现了<code>GameInput</code>接口和<code>GameOutput</code>接口,负责绘图和获取输入<br/>
 * 
 * 进行了简单的双缓存处理，基本避免了屏幕闪烁
 * @author 梦
 */
public class GameBoard extends JFrame implements GameOutput,GameInput{
	
	private static final long serialVersionUID = 2558098042977111L;
	private BufferedImage image;
	private Graphics graphics;
	private CoordinateConverter converter;
	private InputListener il;
	
	GameBoard(int x, int y, int width, int height){
		this.setBounds(x, y, width, height);
		image = new BufferedImage(getWidth(),getHeight(),BufferedImage.TYPE_INT_RGB);
		graphics = image.getGraphics();
		converter = new CoordinateConverter(width, height);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		/**
		 * 对键盘进行监听
		 */
		addKeyListener(new KeyListener() {
			
			@Override
			public void keyTyped(KeyEvent e) {}
			
			@Override
			public void keyReleased(KeyEvent e) {
				char c = Character.toUpperCase(e.getKeyChar());
				if(c!='A'&&c!='D')	return;
				/** 这段代码的详细思路见<code>InputListener</code>接口 */
				if(il!=null)		il.move(new Direction(c=='A'?Math.PI:0),
						InputListener.Status.stop);
			}
			
			@Override
			public void keyPressed(KeyEvent e) {
				char c = Character.toUpperCase(e.getKeyChar());
				if(c!='A'&&c!='D')	return;
				if(il!=null)		il.move(new Direction(c=='A'?Math.PI:0),
						InputListener.Status.start);

			}
		});
		this.setVisible(true);
	}
	
	/**
	 * 在后台先绘图 
	 */
	@Override
	public void draw(Set<Drawable> s){
		graphics.setColor(getBackground());
		graphics.fillRect(0, 0, getWidth(), getHeight());
		graphics.setColor(Color.BLUE);
		for (Drawable thing : s) 
			thing.draw(graphics,converter);
		repaint();		
	}
	
	/**
	 * 把后台图片绘制到前台屏幕
	 */
	@Override
	public void paint(Graphics g) {
		g.drawImage(image, 0, 0, image.getWidth(), 
			image.getHeight(), this);
	}

	@Override
	public void setInputListener(InputListener listener) {
		il = listener;
		
	}
	
	
}
