 import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream; 
 public class UnZipExample {
 	public static void main(String args[]) throws Exception {
		  File file = new File("E:" + File.separator + "L.zip");
		  File outFile = null;
		  ZipFile zipFile = new ZipFile(file);
		  ZipInputStream zipInput = new ZipInputStream(new FileInputStream(file));
		  ZipEntry entry = null;
		  InputStream input = null;
		  OutputStream out = null;
		  while ((entry = zipInput.getNextEntry()) != null) {
			   System.out.println("开始解压缩" + entry.getName() + "文件。。。");
			   File D=new File("E:/L");
			   D.mkdirs();
			   outFile = new File(D.getAbsolutePath() + File.separator + entry.getName());
			   if (!outFile.getParentFile().exists()) {
				   outFile.getParentFile().mkdir();
			   }
			   if (!outFile.exists()) {
				   outFile.createNewFile();
			   }
			   input = zipFile.getInputStream(entry);
			   out = new FileOutputStream(outFile);
			   int temp = 0;
			   while ((temp = input.read()) != -1) {
				   out.write(temp);
			   }
			   input.close();
			   out.close();
		  }
		  System.out.println("Done!");
 }
}