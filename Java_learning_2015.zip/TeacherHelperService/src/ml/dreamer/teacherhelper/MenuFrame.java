package ml.dreamer.teacherhelper;

import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.FlowLayout;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MenuFrame extends JFrame {
	
	private static final long serialVersionUID = -1466870678608497483L;
	private JPanel contentPane;


	/**
	 * Create the frame.
	 */
	public MenuFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 300, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		setTitle("教师助手-菜单");
		
		JButton btnNewButton = new JButton("管理成绩");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ChooseExamFrame().setVisible(true);
			}
		});
		
		final int SIZE = 40;
		btnNewButton.setFont(new Font("yahei", Font.PLAIN, SIZE));
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("管理考试");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ExamManager().setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("yahei", Font.PLAIN, SIZE));
		contentPane.add(btnNewButton_1);
		
		JButton button = new JButton("管理学生");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new StudentManager().setVisible(true);
			}
		});
		
		button.setFont(new Font("yahei", Font.PLAIN, SIZE));
		
		
		contentPane.add(button);
	}

}
