package ml.dreamer.teacherhelper;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class Config {
	public static final String COURSE_TABLE_NAME = "__course__";
	public static final int COURSE_NAME_LENGTH = 50;
	
	public static String[] getCourseList(){
		Connection conn = Main.conn;
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from "+COURSE_TABLE_NAME);
			List<String> rstList = new LinkedList<String>();
			
			while(rs.next()){
				rstList.add(rs.getString(1));
				System.out.println(rs.getString(1));
			}
			System.out.println(rstList);
			String[] rtn = new String[rstList.size()];
			int idx = 0;
			for (String string : rstList) {
				rtn[idx++]=string;
			}
			System.out.println(Arrays.toString(rtn));
	
			rs.close();
			s.close();
			return rtn;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	public static String[] getExamList(){
		Connection conn = Main.conn;
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from "+Exam.EXAM_TABLE);
			List<String> rstList = new LinkedList<String>();
			
			while(rs.next())
				rstList.add(rs.getString(1));
			String[] rtn = new String[rstList.size()];
			int idx = 0;
			for (String string : rstList) {
				rtn[idx++]=string;
			}
	
			rs.close();
			s.close();
			return rtn;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
}
