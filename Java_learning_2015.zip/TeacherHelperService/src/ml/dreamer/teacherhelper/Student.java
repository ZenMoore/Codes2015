package ml.dreamer.teacherhelper;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Student {
	public static final int NAME_LENGTH = 50;
	public static String TABLE_NAME = "__students__";
	private Connection conn;
	
	public Student(Connection conn) {
		this.conn = conn;
	}
	
	public boolean setData(Map<Integer,String> data){
		String dp = "drop table if exists "+TABLE_NAME;
		String ct = "create table if not exists "+TABLE_NAME +"(id int,name varchar("+NAME_LENGTH+"))";
		try {
			Statement s = conn.createStatement();
			s.executeUpdate(dp);
			s.executeUpdate(ct);
			
			Set<Integer> keys = data.keySet();
			StringBuffer sb = new StringBuffer();
			for (Integer integer : keys) {
				String str = "insert into "+TABLE_NAME+" values("+integer+",'"+data.get(integer)+"');";
				sb.append(str);
			}
			
			String sql = new String(sb);
			
			s.executeUpdate(sql);
			s.close();
			
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		
		
	}
	
	public Map<Integer,String> getData(){
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from "+TABLE_NAME+";");
			Map<Integer, String> map = new HashMap<Integer, String>();
			while(rs.next()){
				map.put(rs.getInt(1), rs.getString(2));
			}
			s.close();
			return map;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}

	}
	
	
	public void makeCache(){
		studentTable = new HashMap<Integer, String>();
		try{
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from "+TABLE_NAME);
			while(rs.next()){
				studentTable.put(rs.getInt(1), rs.getString(2));
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
	}
	public void cleanCache(){
		studentTable = null;
	}
	private Map<Integer,String> studentTable;
	public String getNameById(int id){
		if(studentTable == null){
			try {
				Statement s = conn.createStatement();
				System.out.println("select * from "+TABLE_NAME+" where `id`='"+id+"';");
				ResultSet rs = s.executeQuery("select * from "+TABLE_NAME+" where id="+id+";");
				String rtn = null;
				if(rs.next())rtn=rs.getString(2);
				s.close();
				return rtn;
			} catch (SQLException e) {
				e.printStackTrace();
				return null;
			}
		}
		else{
			return studentTable.get(id);
		}
	}
}
