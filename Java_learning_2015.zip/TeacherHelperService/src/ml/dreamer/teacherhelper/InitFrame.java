package ml.dreamer.teacherhelper;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.FlowLayout;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class InitFrame extends JFrame{
	
	private static final long serialVersionUID = 3963104554746857912L;
	private JPanel contentPane;
	private JTextField textField;
	private boolean finished = false;

	public boolean isFinished(){
		return finished;
	}

	/**
	 * Create the frame.
	 */
	public InitFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		setTitle("教师助手-初始化");
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.NORTH);
		panel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JLabel lblNewLabel = new JLabel("您的学生数量");
		panel.add(lblNewLabel);
		
		textField = new JTextField();
		panel.add(textField);
		textField.setColumns(10);
		
		JPanel panel_1 = new JPanel();
		contentPane.add(panel_1, BorderLayout.SOUTH);
		
		JLabel lblNewLabel_1 = new JLabel("在上面输入各个课程名称，每个课程之间以回车分格");
		lblNewLabel_1.setToolTipText("输入各个课程名称，每个课程之间以回车分格");
		panel_1.add(lblNewLabel_1);
		
		JButton button = new JButton("确定");
		JTextArea textArea = new JTextArea();
		textArea.setToolTipText("输入各个课程名称，每个课程之间以回车分格");
		contentPane.add(textArea, BorderLayout.CENTER);
		
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					int studentCount = Integer.parseInt(textField.getText().trim());
					if(studentCount<=0){
						JOptionPane.showMessageDialog(null, "一个学生都没有？");
					}else{
						setStudents(studentCount);
					}
				}catch(Exception e1){
					JOptionPane.showMessageDialog(null,"学生人数是阿拉伯数字哦！");
				}
				new Thread(()->{JOptionPane.showMessageDialog(null,"耐心等等吧，\n主窗口会自动关闭的。\n请点击确定");}).start();
				String str = textArea.getText().trim();
				Scanner s = new Scanner(str);
				int cnt = 0;
				while(s.hasNextLine()){
					s.nextLine();
					cnt++;
				}
				String strs[] = new String[cnt];
				s.close();
				s = new Scanner(str);
				cnt = 0;
				while(s.hasNextLine()){
					strs[cnt++]=s.nextLine();
				}
				setCourses(strs);
				s.close();
				Exam exam = new Exam(Main.conn, "DemoExam");
				exam.create();exam.initData();
				dispose();
				finished = true;
			}
		});
		panel_1.add(button);
	}

	protected void setStudents(int studentCount) {
		Map<Integer,String> map = new HashMap<Integer, String>();
		for(int i = 1;i<=studentCount;i++){
			map.put(i, "st"+i);
		}
		new Student(Main.conn).setData(map);
	}

	protected void setCourses(String[] strs) {
		Connection conn = Main.conn;
		try {
			String sql = "create table if not exists "+Config.COURSE_TABLE_NAME+" (course varchar("+Config.COURSE_NAME_LENGTH+"));";
			Statement sm = conn.createStatement();
			System.out.println(sql);
			sm.executeUpdate(sql);
			sm.close();
			for(int i = 0; i < strs.length; i++){
				String t = "insert into "+Config.COURSE_TABLE_NAME+" values('"+strs[i]+"');";
				PreparedStatement ps = conn.prepareStatement(t);
				ps.executeUpdate();
				ps.close();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
