package ml.dreamer.teacherhelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;
import java.util.Set;

public class Exam {
	private Connection conn;
	private String examName;
	private String [] courses;
	public static final int EXAM_NAME_LENGTH = 100;
	public static final String EXAM_TABLE = "__examtable__";
	
	/**
	 * @param conn 数据库连接对象
	 * @param examName 考试名称，要求唯一
	 * @param courses 课程名称
	 */
	public Exam(Connection conn,String examName) {
		this.conn = conn;
		this.examName = examName;
		this.courses = Config.getCourseList();
	}
	
	
	/**
	 * 添加考试
	 * @return boolean 是否成功创建
	 */
	public boolean create(){
				
		String courseStr;
		StringBuffer sb = new StringBuffer();
		for(int i = 0;i < courses.length-1; i++){
			sb.append(courses[i]+" int,");
		}
		sb.append(courses[courses.length-1]+" int");
		courseStr = new String(sb);
		try {
			System.out.println("create table if not exists "+ examName
							+ "(id int,name varchar("+Student.NAME_LENGTH+")," + courseStr + ")");
			PreparedStatement s = 
					conn.prepareStatement("create table if not exists "+ examName
							+ "(id int,name varchar("+Student.NAME_LENGTH+")," + courseStr + ")");
			
			
			s.execute();
			s.close();
			s = conn.prepareStatement("create table if not exists "+EXAM_TABLE+" (exam varchar("+EXAM_NAME_LENGTH+"))");
			s .execute();s.close();
			
			
			s = conn.prepareStatement("select * from "+EXAM_TABLE+" where exam=?");
			s.setString(1, examName);
			if(!s.executeQuery().next()){
				s.close();
				s = conn.prepareStatement("insert into "+EXAM_TABLE+" values(?)");
				s.setString(1, examName);
				s.execute();s.close();
			}
			
			return true;
		
		
		
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} 
		//TODO 考试表
	}


	public boolean initData() {
		try{
			Statement sm = conn.createStatement();
			Student student = new Student(Main.conn);
			Map<Integer, String> map = student.getData();
			Set<Integer> keys = map.keySet();
			String str = "";
			for(int i = 0;i < courses.length;i++){
				str+=",-2";
			}
			for (Integer integer : keys) {
				System.out.println("insert into "+examName+" values ("+integer+",'"+map.get(integer)+"'"+str+",0)");
				sm.execute("insert into "+examName+" values ("+integer+",'"+map.get(integer)+"'"+str+")");
			}
			sm.close();
			return true;
		}catch(SQLException e){
			e.printStackTrace();
			return false;
		}
	}
	
	/**
	 * 删除本次考试
	 * @return boolean 是否成功
	 */
	public boolean delete(){
		PreparedStatement s;
		try {
			s = conn.prepareStatement("drop table if exists "+examName+";");
			s.execute();
			s.close();
			s = conn.prepareStatement("delete from "+EXAM_TABLE+" where exam='"+examName+"'");
			s.execute();
			s.close();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		//TODO 考试表
	}
	
	/**
	 * 
	 * @param data 数据						<br/>
	 *
	 * !!! Warning !!!
	 * 会覆盖已经存在的数据
	 * 
	 * 	<pre>
	 * ----------------
	 * |学生	|科目1|科目2|(第二维)
	 * ----------------
	 * |id1	|成绩1|成绩3|	
	 * ----------------
	 * |id2	|成绩2|成绩4|	
	 * ----------------
	 * (第一维)
	 * 
	 * 缺考      ->  -1	(非正常原因未参加考试) 
	 * 未这门选课 ->  -2	(大学和实行走班制的中学) 
	 * </pre>
	 * 
	 * @return boolean 是否成功
	 */
	public boolean setData(Object [][] data){
		/**
		 * Clean the table firstly;
		 */
		delete();
		create();
		
		boolean rtn = true;
		for(int i = 0;i < data.length;i++){
			if(!insert(data[i]))rtn = false;
		}
		return rtn;
	}
	
	/**
	 * 获取数据
	 * @return 二维数组 
	 * @see Exam#setData(int[][])
	 */
	public Object[][] getData(){
		try {
			PreparedStatement s = conn.prepareStatement("select * from "+examName+";");
			
			ResultSet rs = s.executeQuery();
			int n = 0;
			while(rs.next())n++;
			Object[][] rst = new Object[n][courses.length+2];
			
			rs = s.executeQuery();
			n=0;
			while(rs.next()){
				rst[n][0] = rs.getInt(1);
				rst[n][1] = rs.getString(2);
				for(int i = 0; i<courses.length;i++){
					rst[n][i+2] = rs.getInt(i+3);
				}
				n++;
			}
			
			rs.close();
			s.close();
			
			return rst;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}		
	}	
	
	
	/**
	 * 添加一行的数据
	 * @param line
	 * @return
	 */
	private boolean insert(Object[] line){
		//if(!create())return false;
		
		String t;
		StringBuffer sb = new StringBuffer();
		for(int i = 2;i<line.length-1;i++)
			sb.append((Integer)line[i]+",");
		sb.append((Integer)(line[line.length-1]));
		t = new String(sb);
		
		
		String sql = "insert into "+examName+" values (?,?,"+t+")";
		PreparedStatement ps;
		try {
			System.out.println(sql);
			ps = conn.prepareStatement(sql);
//			ps.setString(1, examName);
			ps.setInt(1, (int) line[0]);
			ps.setString(2, (String) line[1]);
			ps.execute();
			ps.close();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}
