package ml.dreamer.teacherhelper;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.SwingUtilities;

public class Main {
	public static Connection conn;
	
	
	public static void start() {
		
		InitFrame i = new InitFrame();
		File f = new File(System.getProperty("user.dir")+"/examdata.db");
		if((!f.exists())||f.isDirectory()||f.length()<1){
			try {
				conn = DriverManager.getConnection("jdbc:sqlite://"+System.getProperty("user.dir")+"/examdata.db");
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			SwingUtilities.invokeLater(()->{
				i.setVisible(true);
			});
			while(!i.isFinished()){
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
		}else{
			try {
				conn = DriverManager.getConnection("jdbc:sqlite://"+System.getProperty("user.dir")+"/examdata.db");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		new MenuFrame().setVisible(true);

		
		
	}
	static{
		try {
			Class.forName("org.sqlite.JDBC");
			conn = DriverManager.getConnection("jdbc:sqlite://"+System.getProperty("user.dir")+"/examdata.db");
			System.out.println("jdbc:sqlite://"+System.getProperty("user.dir")+"/examdata.db");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
}
