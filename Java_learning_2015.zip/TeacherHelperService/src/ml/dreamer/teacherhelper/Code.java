package ml.dreamer.teacherhelper;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;

public class Code {
	private Image image;
	private String str;
	Code(){
		str="";
		for(int i = 0; i < 4 ;i++){
			int a = (int) (Math.random()*10);
			str += a;
		}
		
		image = new BufferedImage(200, 80, BufferedImage.TYPE_INT_RGB);
		Graphics g = image.getGraphics();
		for(int i = 0;i<10;i++){
			g.setColor(new Color((int)(Math.random()*255),(int)(Math.random()*255),(int)(Math.random()*255)));
			g.drawLine((int)(Math.random()*10),(int)(Math.random()*100),(int)(Math.random()*200), (int)(Math.random()*100));
		}
		g.setFont(new Font("yahei", Font.PLAIN, 60));
		g.drawString(str, 5, 70);
	}
	public boolean isRight(String str){
		return str.equals(this.str);
	}
	public Image getImage(){
		return image;
	}
}
