package ml.dreamer.teacherhelper;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class CodeFrame extends JFrame {

	private static final long serialVersionUID = 6005655391602392912L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CodeFrame frame = new CodeFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CodeFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		JPanel p = new JPanel();
		p.setLayout(new FlowLayout());
		add(p,BorderLayout.SOUTH);
		Code code = new Code();
		ImageIcon icon = new ImageIcon(code.getImage());
		JLabel jlabel = new JLabel(icon);
		add(jlabel);
		JTextField txt = new JTextField();
		txt.setToolTipText("输入验证码");
		txt.setColumns(10);
		p.add(txt);
		JButton btn = new JButton("确定");
		p.add(btn);
		JLabel jl = new JLabel("为了避免您家中打婴幼儿误操作，请输入验证码");
		add(jl,BorderLayout.NORTH);
		setTitle("输入验证码");
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(code.isRight(txt.getText().trim().toLowerCase())){
					Main.start();
					dispose();
				}else{
					JOptionPane.showMessageDialog(null, "输入错误，请重试！");
					dispose();
					new CodeFrame().setVisible(true);
				}
			}
		});
		
	}

}
