package ml.dreamer.teacherhelper;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

public class ChooseExamFrame extends JFrame {

	private JPanel contentPane;

	/**
	 * Create the frame.
	 */
	public ChooseExamFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		setTitle("选择考试");
		JList<String> list = new JList<String>(Config.getExamList());
		add(new JScrollPane(list));
		JButton btn = new JButton("确定");
		add(btn,BorderLayout.SOUTH);
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new ScoreFrame(list.getSelectedValue()).setVisible(true);
				dispose();
			}
		});
	}

}
