package ml.dreamer.teacherhelper;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JToolBar;
import javax.swing.border.EmptyBorder;


class StudentManager extends JFrame {

	private static final long serialVersionUID = -6321322221513609203L;
	private JPanel contentPane;
	private String[][] data;
	
	/**
	 * Create the frame.
	 * @return 
	 */
	
	public StudentManager() {
		data = mapToData(new Student(Main.conn).getData());
		
		setTitle("学生管理");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		setTitle("学生信息");
		
		JTable tb = new JTable(data = toObjectArray(data),new String[]{"ID","姓名"});
		JScrollPane sp = new JScrollPane(tb);
		
		//contentPane.add(tb.getTableHeader(),BorderLayout.PAGE_START);
		contentPane.add(sp);
		JToolBar TBBot = new JToolBar();
		JButton btnSave = new JButton("保存");
		btnSave.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				StudentManager.this.save();
			}
		});
		JButton btnSaveAndQuit = new JButton("保存并退出");
		btnSaveAndQuit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				boolean succeeded = StudentManager.this.save();
				if(succeeded) StudentManager.this.dispose();
			}
		});
		JButton btnQuitWithoutSaving = new JButton("退出但不保存");
		btnQuitWithoutSaving.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				StudentManager.this.dispose();
			}
		});
		TBBot.add(btnSave);
		TBBot.add(btnSaveAndQuit);
		TBBot.add(btnQuitWithoutSaving);
		contentPane.add(TBBot,BorderLayout.PAGE_END);
		
	}

	private String[][] mapToData(Map<Integer, String> data2) {
		Set<Integer> keys = data2.keySet();
		String strs[][] = new String[keys.size()][2];
		int idx = 0;
		for (Integer integer : keys) {
			strs[idx][0]=integer+"";
			strs[idx][1]=data2.get(integer);
			idx++;
		}
		return strs;
	}

	private String[][] toObjectArray(Object[][] data2) {
		String[][] rtn = new String[data2.length][data2[0].length];
		for(int i = 0;i < data.length;i++){
			rtn[i][0]=data2[i][0].toString();
			rtn[i][1]=data2[i][1].toString();
		}
		return rtn;
	}
	private boolean finished;
	private boolean succeeded;
	private boolean save() {
		new Thread(()->{
			Map<Integer,String> map = new HashMap<Integer, String>();
			for (Object[] objects : data) 
				map.put(Integer.parseInt( (String)objects[0]), (String)objects[1]);
			System.out.println(map);
			succeeded = new Student(Main.conn).setData(map);
			this.finished = true;
		}).start();
		
		JOptionPane.showMessageDialog(null, "正在保存!\n请点击确定");
		while(!finished){
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		if(succeeded){
			JOptionPane.showMessageDialog(null,"保存成功！\n");
		}else{
			JOptionPane.showMessageDialog(null,"保存失败！\n");	
		}
		return succeeded;
	}

}
