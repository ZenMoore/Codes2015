package ml.dreamer.teacherhelper;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JToolBar;
import javax.swing.border.EmptyBorder;

public class ScoreFrame extends JFrame {

	private static final long serialVersionUID = 3512978286425431610L;
	private JPanel contentPane;
	private String examName;

	/**
	 * Create the frame.
	 */
	public ScoreFrame(String examName) {
		this.examName = examName;
		setTitle("成绩管理");
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		initUI();
	}
	
	private void initUI() {
		setLayout(new BorderLayout());
		Object[][] obj = new Exam(Main.conn, examName).getData();
		String[] courses = Config.getCourseList();
		String[] arg = new String[2+courses.length];
		arg[0] = "ID";
		arg[1] = "姓名";
		for(int i = 0; i < courses.length; i++){
			arg[i+2]=courses[i];
		}
		Student s = new Student(Main.conn);
		for(int i = 0; i < obj.length;i++){
			obj[i][1] = s.getNameById((Integer)obj[i][0]);
		}
		
		
		JTable tb = new JTable(obj,arg);
		JScrollPane pane = new JScrollPane(tb);
		add(pane,BorderLayout.CENTER);
		
		JToolBar TBBot = new JToolBar();
		JButton btnSave = new JButton("保存");
		btnSave.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ScoreFrame.this.save(obj);
			}
		});
		JButton btnSaveAndQuit = new JButton("保存并退出");
		btnSaveAndQuit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				boolean succeeded = ScoreFrame.this.save(obj);
				if(succeeded) ScoreFrame.this.dispose();
			}
		});
		JButton btnQuitWithoutSaving = new JButton("退出但不保存");
		btnQuitWithoutSaving.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				ScoreFrame.this.dispose();
			}
		});
		TBBot.add(btnSave);
		TBBot.add(btnSaveAndQuit);
		TBBot.add(btnQuitWithoutSaving);
		contentPane.add(TBBot,BorderLayout.PAGE_END);
		
	}
	private boolean save(Object [][] obj) {
		
		new Thread(()->{
			JOptionPane.showMessageDialog(null, "正在保存，\n请点击确定");
		}).start();
		
		Exam e = new Exam(Main.conn, examName);
		Object[][] data = e.getData();
		for (int i = 0; i < data.length; i++) {
			for (int j = 2; j < data[i].length; j++) {
				data[i][j]=Integer.parseInt(obj[i][j].toString());
			}
		}
		
		return e.setData(data);
	}
}
