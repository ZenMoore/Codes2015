package ml.dreamer.teacherhelper;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

public class ExamManager extends JFrame {

	private static final long serialVersionUID = -6388584748176891471L;
	private JPanel contentPane;
	private String[] examList ;
	private boolean finished = false;
	
	public boolean isFinished(){
		return finished;
	}
	
	
	/**
	 * Create the frame.
	 */
	public ExamManager() {
		setTitle("管理考试");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		examList = Config.getExamList();
		JList<String> l = new JList<String>(examList);
		
		JButton btnAdd = new JButton("添加");
		JButton btnDelete = new JButton("删除");
		btnDelete.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					Main.conn.close();
					Main.conn = DriverManager.getConnection("jdbc:sqlite://"+System.getProperty("user.dir")+"/examdata.db");
					new Exam(Main.conn,l.getSelectedValue()).delete();	
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
				System.out.println(l.getSelectedValue());
				if(examList.length==1){
					Exam demo = new Exam(Main.conn,"DemoExam");
					demo.create();
					demo.initData();
					examList = Config.getExamList();
				}
				dispose();
			}
		});
		
		btnAdd.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String str = JOptionPane.showInputDialog(null, "请输入考试名称","exam"+System.currentTimeMillis() );
				Exam exam = new Exam(Main.conn,str);
				exam.create();
				exam.initData();
				dispose();
			}
		});
		JButton btnExit = new JButton("退出");
		btnExit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				finished = true;
				dispose();
			}
		});
		JPanel panelBottom = new JPanel(new FlowLayout());
		panelBottom.add(btnAdd);
		panelBottom.add(btnDelete);
		panelBottom.add(btnExit);
		add(new JScrollPane(l));
		add(panelBottom,BorderLayout.SOUTH);
		
	}

}
