
public class Staticexample {
		static{
//			int number=11;
//			String str=new String("I'm Javc.");
			System.out.println("Yes,you are right.");
		}
	
	public static void main(String[] args) {
		Staticexample ex=new Staticexample();
		

	}

}
