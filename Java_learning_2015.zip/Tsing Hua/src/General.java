
public class General {
	public static void main(String[] args){
			String s1=String.format("%n");
			System.out.println("00000");
			System.out.println(s1);
	}
}
