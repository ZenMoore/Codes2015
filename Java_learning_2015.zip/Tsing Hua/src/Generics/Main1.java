package Generics;

public class Main1<T extends Main> {
	Main1(Main main){
		
	}
	public void ran(){
		
	}
	public static void main(String[] args){
		Main2<Main> a=new Main2<Main>();
		
	}
}
class Main2<T1,T2,T3> extends Main1<Main>{

	Main2(Main main) {
		super(main);
		// TODO Auto-generated constructor stub
	}
	
}
