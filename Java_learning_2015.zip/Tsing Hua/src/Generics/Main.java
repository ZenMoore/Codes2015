package Generics;
public class Main {
	interface EnumFa{
		public String getDesc();
	}
	enum Constants implements EnumFa{
		A("a",65),B("b",66),C("c",67),D("d",68);
		private String desc;
		private int num;
		private Constants(String desc,int num){
			this.desc =desc;
			this.num=num;
		}
		public int getInt(){
			return this.num;
		}
		@Override
		public String getDesc() {
			return this.desc;
		}
	}
	public static void main(String[] args){
		System.out.println(Constants.A.getInt());
	}
}
