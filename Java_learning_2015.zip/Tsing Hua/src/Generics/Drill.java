package Generics;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
public class Drill<T extends List>{
	public static void main(String[] args){
		Drill<LinkedList> l=new Drill<LinkedList>();
		Drill<ArrayList> a=new Drill<ArrayList>();
		Drill1<? extends List> a1=null;
		a1=new Drill1<LinkedList>();
		a1=new Drill1<ArrayList>();
		//这里强调一个知识点：Drill1<?>与Drill1的区别在于，对前者实例化的对象中的信息只能获取(get)或删除(remove),而后者相对处理的权利就比较广泛了(如可以set，然而前者不能)
	}
}
class Drill1<T extends List> extends Drill{
	
}