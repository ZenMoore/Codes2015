
public class charca {
	public static void main(String[] args){
		System.out.println(Character.CONNECTOR_PUNCTUATION);
	}
}
