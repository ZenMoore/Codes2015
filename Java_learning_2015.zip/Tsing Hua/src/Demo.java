
public class Demo {
	public static void setFormat(String pattern,double value){
		
	}
	
	public static void setFormat2(String pattern,double value){
		
	}

	public static void main(String[] args) {
		// TODO �Զ����ɵķ������

	}

}
