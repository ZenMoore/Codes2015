package Eleven;

public class ExtendL extends ClassA .ClassB{
	ExtendL(ClassA a){
		a.super();
	}
	
	@Override 
	protected void doit(){
		System.out.println("This isExtendL.doit();");
	}
}

class ClassA{
	class ClassB{
		protected void doit(){
			System.out.println("This is aClassB.doit();");
		}
	}
		
	}

