package Eleven;

public class Static {
	private  int i;
	
	protected void doit(){
		System.out.println("Static Doit.");
	}

	static class Inner{
		protected void doit(){
			System.out.println("Inner Doit.");
		}

		public static void main(String[] args){
			Inner in=new Inner();
		}
	}
	
}
