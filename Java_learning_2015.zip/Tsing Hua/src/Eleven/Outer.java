package Eleven;

import Eleven.ClassA.ClassB;

interface outInterface{}

public class Outer {
//	Inner in=new Inner();
	
	protected outInterface doit(final String s){
		class Inner implements outInterface{
			Inner(String x){			    
                x=s;
				System.out.println(s);
			}
		}
		return new Inner("doit");
	}
//	private int x=999;

//	protected void uter(){
//		System.out.println("Outer Method.");
//	}
	
//	这个是内部类的定义
		public class Inner{
			private int i=0;
			private int x=0;
			protected void nner(){
			System.out.println("Inner Method.");
			}
			protected void dothis(){
				System.out.println(this.x);
//				System.out.println(Outer.this.x);
			}
		}
	//直到这里
	
//		public Inner doit(){
//			in.i=4;
//			return new Inner();
//		}
		
//	public static void main(String[] args){
//		Outer out=new Outer();
//		out.doit("this");
//		Outer.Inner in=out.new Inner();
//		Outer.Inner inn=out.doit();
//		Outer.Inner inn1=out.new Inner();
//		System.out.println(inn.i);
//		System.out.println(inn1.i);
//		out.in.dothis();
		public static void main(String[] args){
			ClassA a=new ClassA();
			ExtendL e=new ExtendL(a);
			ClassA.ClassB b=a.new ClassB();
			b.doit();
			e.doit();
	}
}

