import java.util.Date;

public class Eval {

	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
		Date date=new Date();
		String year=String.format("%tY", date);
		String month=String.format("%tb",date);
		String day=String.format("%td",date);
		String week=String.format("%ta",date);
		String infor=String .format("%tc",date);
		System.out.println(infor);
//		System.out.printf("%s %s %s %s",year,month,day,week);
	}

}
