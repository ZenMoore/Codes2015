package MultiThreading;
import javax.swing.*;
import java.awt.*;
public class Test extends JFrame implements Runnable{
	private JProgressBar progress=new JProgressBar();
	Thread thread;
	Test(){
		
	}
	@Override
	public void run() {
		
		
	}
	protected void init(JFrame frame,int height,int width){
		
	}
}
