package MultiThreading;
public class Main2 implements Runnable{
	@Override
	public void run() {
//		while(true){
			System.out.println("TWO  ");
//		}
		
	}

}
