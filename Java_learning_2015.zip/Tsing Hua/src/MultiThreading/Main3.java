package MultiThreading;
public class Main3 implements Runnable{
	int num=10;
	@Override
	public void run() {
		doit();
	}
	protected synchronized void doit(){
		while(true){
			if(num>0){
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Tickets"+num--);
			}else{
				break;
			}
		}
	}
//	public static void main(String[] args){
//		Main3 main=new Main3();
//		Thread A=new Thread(main);
//		Thread B=new Thread(main);
//		Thread C=new Thread(main);
//		Thread D=new Thread(main);
//		A.start();
//		B.start();
//		C.start();
//		D.start();
//	}
	
}
