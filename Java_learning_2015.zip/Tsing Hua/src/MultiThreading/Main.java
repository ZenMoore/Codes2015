package MultiThreading;
import java.lang.Thread;
public class Main extends Thread{
	Main(String Name){
		super(Name);
	}
	Main(){
		super();
	}
	@Override
	public void run(){
//		while(true){
			System.out.print("ZERO  ");
//		}
	}
//	public static void main(String[] args){
//		new Main("Test.").start();
//		new Main1().start();
//		new Thread(new Main2()).start();
//	}
}
