package MultiThreading;
public class Main1 extends Thread{
	@Override
	public void run(){
//		while(true){
			System.out.print("ONE  ");
//		}
	}
}
