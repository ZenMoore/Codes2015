import java.math.BigInteger;
import java.util.Random;
import java.math.BigDecimal; 

public class DemoofMath {

	public static void main(String[] args) {
//		Random random=new Random();
//		System.out.println(random.nextGaussian());
//		BigInteger big=new BigInteger("23");
//		System.out.println();
		BigDecimal big=new BigDecimal(2.5);
		double demo=big.doubleValue();
		BigDecimal big1=new BigDecimal(2);
//		System.out.println(big.divide(big1,BigDecimal.ROUND_DOWN));
		System.out.printf("%.f",demo);
	}
	

}
