public class Builder {

	public static void main(String[] args) {
		String str=new String("I'm Javc.");
		StringBuilder bf =new StringBuilder(str);
//		bf.append(true);
//		bf.insert(3," a ");
//		bf.delete(4, 7);
		System.out.println(bf.toString());
		
		
		

	}

}
