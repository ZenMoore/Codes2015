import java.util.Arrays;

public class OperationOfArrays {

	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
//		int a[]=new int[]{0,1,2,3,4,6,7,8,9,};
//		Arrays.fill(a,1,5,55);
//		for(int i=0;i<a.length;i++){
//			System.out.println(a[i]);
//		}
		int a[]=new int []{1,2,3,4,5,6,7,21,123};
		Arrays.sort(a);
		int w=Arrays.binarySearch(a,2,6,6);
		System.out.print(w);
		  }
}
