package Fifteen;
import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import java.io.*;
public class IOL {
	public static void main(String[] args){
		String[] content={"Long time no see.","How's it going?","Keep in touch"};
		File file=new File("E:/L/letter.txt");
		try{
			FileOutputStream fs=new FileOutputStream(file);
			DataOutputStream ds=new DataOutputStream(fs);
			ds.writeUTF("Use writeUTF.");
			ds.writeBytes("Use writeBytes.");
			
			ds.writeChars("Use writeChars.");
			ds.close();
			FileInputStream fis=new FileInputStream(file);
			DataInputStream dis=new DataInputStream(fis);
			System.out.println(dis.readUTF());
		}catch(EOFException e){
			System.out.println("EOFException.");
		}catch(IOException e){
			e.printStackTrace();
		}
		try{
			
		}catch(Exception e){
			e.printStackTrace();
		}

	}
	

}
	
	

