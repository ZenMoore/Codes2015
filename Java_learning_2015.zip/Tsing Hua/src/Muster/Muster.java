package Muster;
import java.util.*;
public class Muster {
	private String name;
	private long id;
	private static int i=1;
	
	public Muster(long id){
		this.id=id;
		this.name="the "+i+++" one.";
	}
	
	@Override
	public String toString(){
		return name;
	}

	public static void main(String[] args){
		Map<Long,Muster> map=new HashMap<Long,Muster>();
		Muster m1=new Muster(001);
		map.put(m1.id,m1);
		Muster m2=new Muster(002);
		map.put(m2.id, m2);
		Muster m3=new Muster(003);
		map.put(m3.id, m3);
		Muster m4=new Muster(004);
		map.put(m4.id, m4);
		Muster m5=new Muster(005);
		map.put(m5.id, m5);
		Muster m6=new Muster(006);
		map.put(m6.id, m6);
		Muster m7=new Muster(007);
		map.put(m7.id, m7);
		map.remove(005L);
		Iterator it=map.values().iterator();
		while(it.hasNext()){
			System.out.print(it.next().toString()+" ");
		}
		System.out.println();
		it=map.keySet().iterator();
		while(it.hasNext()){
			System.out.print(it.next()+" ");
		}
		
//		List<Integer> list=new ArrayList<Integer>();
//		for(int i=1;i<=100;i++){
//			list.add(i);
//		}
//		list.remove(10);
//		Iterator it=list.iterator();
//		StringBuilder sb=new StringBuilder();
//		while(it.hasNext()){
//			sb.append(it.next()+" ");
//		}
//		System.out.println(sb.toString().trim());
//		HashMap<Muster,Integer> hash=new HashMap<Muster,Integer>();
//		Collection<Integer>  tree=hash.values();
//		for(Muster a:hash.keySet()){
//			
//		}
//		for(Integer a:tree){
//			
//		}
		
//		list.add("aaa");
//		list.add("bbb");
//		list.add("ccc");
//		Iterator<String> it=list.iterator();
//		while(it.hasNext()){
//			System.out.println((String)it.next());
//		}
	
		
	}
}
