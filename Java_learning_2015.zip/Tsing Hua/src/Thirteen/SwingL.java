package Thirteen;
import java.awt.*;
import javax.swing.*;
public class SwingL extends JFrame{
	public void CreateJFrame(String title){
		JFrame jf=new JFrame();
		Container container=jf.getContentPane();
		JLabel jl=new JLabel("This is a JFrame Window.");
		jl.setHorizontalAlignment(SwingConstants.CENTER);
		container.add(jl);
		container.setBackground(Color.gray);
		jf.setVisible(true);
		jf.setSize(200, 150);
		jf.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
	}
	public static void main(String[] args) {
		new SwingL().CreateJFrame("JFrame");

	}

}
