
public class ReverseSort {
	
	private void sort(int[] array){ 
		for(int i=0;i<array.length/2;i++){
			int temp=array[i];
			array[i]=array[array.length-i-1];
			array[array.length-i-1]=temp;
		}
		showArray(array);
	}
	
	private void showArray(int[] array){
		for(int i:array){
			System.out.print(">"+i);
		}
	}

	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
		int[] array={11,22,33,44,55,66,77,88,99,};
		ReverseSort sorter=new ReverseSort();
		sorter.sort(array);
	}

}
