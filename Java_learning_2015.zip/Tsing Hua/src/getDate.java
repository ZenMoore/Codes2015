import java.util.Date;

public class getDate {

	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
		Date date=new Date();
		String hour=String.format("%tH",date);
		String minute=String .format("%tM",date);
		String second=String .format("%tS",date);
		String miniSecond=String.format("%tL",date);
		String M=String .format("%tp",date);
		String area=String .format("%tz",date);
		String Area=String .format("%tZ",date);
		String cont=String .format("%ts",date);
		String count=String .format("%tQ",date);
		System.out.printf("%s %s %s %s %s %s %s %s %s",hour,minute,second,miniSecond,M,area,Area,cont,count);
	}

}
