
public class Integ {

	public static void main(String[] args) {
		
//		String str=new String("1999");
//		int integ=Integer.parseInt(str);
//		System.out.println(integ);
		String str=new String();
		Integer integ=new Integer(1685); 
//		str=Integer.toBinaryString(integ);
//		str=Integer.toHexString(integ);
		str=Integer.toOctalString(integ);
		System.out.println(str);
		
		Class<Integer> i=Integer.TYPE;
		
	}

}
