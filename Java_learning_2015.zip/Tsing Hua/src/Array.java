
public class Array {
	public static void main(String[] args){
//		int[] number={0,1,2,3,4,5,6,7,8,9,};
//		int[] number=new int[]{0,1,2,3,4,5,6,7,8,9,};
//		for(int i=0;i<number.length;i++){
//			number[i]=0;
//		}
		
		System.out.println();
	}
}
