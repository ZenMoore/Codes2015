package Kinds;

public class Children extends Partents{

	private void get(){
//		System.out.println(super.getClass().getName());
		System.out.println("Right");
	}
	
	@Override
	public String toString() {
		return 	super.getClass().getName();
		}

	@Override 
	protected void print(){
		System.out.println("Children/");
	}
	
	public static void main(String[] args){
		Partents partents=new Children();
		Partents par=new Partents();
		Children child=new Children();
		try{
			Children parent=(Children)new Partents();
		}catch(ClassCastException a){
			System.out.println("ok");
		}
		partents.print();
		par.print();
		child.print();
//		parent.print();
//			children.get();
//			System.out.println(children.toString());
			
	}
}