package Kinds;

public class Partents {
	
//	private String get1(){
//		return "String";
//	}
//	
//	private int get1(){
//		return "int";
//	}

	protected void print(){
		System.out.println("Father/");
	}
	
	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
		Children chld=(Children)new Partents();
	}

}
