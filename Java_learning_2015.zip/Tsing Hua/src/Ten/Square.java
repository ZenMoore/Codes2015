package Ten;

public class Square extends Picture{
	@Override 
	public void draw(){
		System.out.println("Draw Square");
	}
	public static void main(String[] args) {
		// TODO 自动生成的方法存根

	}

}
