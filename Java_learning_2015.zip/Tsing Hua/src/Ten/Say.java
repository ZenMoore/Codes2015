package Ten;

public interface Say {
	public void say();

}
