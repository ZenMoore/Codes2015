package Ten;

public class Triangle extends Picture implements Say{
	
	@Override 
	public void draw(){
		System.out.println("Draw Triangle");
	}

	@Override
	public void say(){
		System.out.println("I can speak.");
	}
	
	public static void main(String[] args) {
		// TODO 自动生成的方法存根
		Say say=new Triangle();
	}

}
