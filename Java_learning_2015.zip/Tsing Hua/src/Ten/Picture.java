package Ten;

public abstract class Picture {
	
	public abstract void draw();
	
	public void print(){
		System.out.println("这是非抽象方法");
	}
	
	public static void main(String[] args){
		Picture picture=new Triangle();
		Say say=new Triangle();
		Triangle triangle=new Triangle();
		triangle.print();
		say.say();
		picture.draw();
		picture.print();
	}
	
}
