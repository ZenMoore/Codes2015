
public class Division {

	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
		String str=new String ("abc,def,ghi,jkl");
//		String[] newstr=str.split(",");
//		for(int i=0;i<newstr.length;i++){
//			System.out.println(newstr[i]);
//		}
		String[] newstr2=str.split(",",100);
		for(int i=0;i<newstr2.length;i++){
			System.out.println(newstr2[i]);
		}
		
	}

}
