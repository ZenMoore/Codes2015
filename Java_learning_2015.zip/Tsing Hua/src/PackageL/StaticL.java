package PackageL;

import static java.lang.Math.max;
import static java.lang.System.out;

public class StaticL {

	public static void main(String[] args) {
		out.print(max(1,2));
	}

}
