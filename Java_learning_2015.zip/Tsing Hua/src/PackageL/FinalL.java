package PackageL;

final class FinalL {
	final int a=3;
	
	void doit(){
		System.out.println("ok");
	}
	
	public static void main(String[] args) {
		// TODO 自动生成的方法存根
		FinalL f=new FinalL();
		System.out.println(f.a);
	}

}
