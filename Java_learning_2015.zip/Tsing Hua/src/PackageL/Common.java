package PackageL;

public class Common {

	public static void main(String[] args) {
		// TODO 自动生成的方法存根
		System.out.println(Math.max(1, 4));
	}

}
