package Twelve;

public class Computer{
	
	protected static int count(int a,int  b) throws MyException{
		int result=1;
		int rem=0;
		if(a<0||b<0){
				throw new MyException();
		}
		if(a%b==0||b%a==0){
				result=(a<=b?a:b);
		}else{
			while(true){
				rem=a;
				a=b;					
				b=rem%b;
				if(b==0) {result=a;break;}
			}
		}
		return result;
	}
	
	public static void main(String[] args){
		try{
			System.out.println(Computer.count(12,-1));
		}catch(MyException e){
			System.out.println("Sorry,You cant pass this negative value.");
		}
		finally{
			System.out.println("OK.");
		}
	}
}

class MyException extends Exception{
	 MyException(){
		super();
	}
}
