
public class Bool {

	public static void main(String[] args) {
		boolean boo=Boolean.parseBoolean("true");
		Boolean boole=boo;
		
;		String str=Boolean.toString(boole);
//		System.out.println(boole);
		System.out.println(str);

	}

}
