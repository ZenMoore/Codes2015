import java.util.Date;

public class DateAndTime {

	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
		Date date=new Date();
		System.out.println(String.format("%tF",date)+String.format("%tD",date)+String.format("%tr",date)+String.format("%tT",date));
		System.out.println(String.format("%tR",date));
	}

}
