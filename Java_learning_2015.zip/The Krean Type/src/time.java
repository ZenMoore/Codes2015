import java.util.Scanner;


public class time {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in=new Scanner (System.in);
		while(true)
		{
			String s1=new String();
			String type=new String();
			int god=15000;
			System.out.println("施主，敲下1-9这九个数字后戳回车，万能的开发者会给你一串（可能是一串...）韩文。(1->9越来越长了呢..)\nT*T亲亲");
			int serve=in.nextInt();
			switch(serve)
			{
			case 1:System.out.println(s1="신기한 현상이다");break;
			case 2:System.out.println(s1="왜 한국 사람은 골프에 미칠까");break;
			case 3:System.out.println(s1="고스톱처럼 내기 골프도 이런저런 반전의 장치를 만들었다");break;
			case 4:System.out.println(s1="아무튼,며칠 전 약간 쌀쌀한 날씨에 짙은 안개가 자욱했던 어느 날.");god=30000;break;
			case 5:System.out.println(s1="한국인에게 골프의 유전자가 있는 것이 아니라 골프에 고스톱의 유전자가 있는 셈인가");god=30000;break;
			case 6:System.out.println(s1="세계 어디에서든 비바람이 불고 눈이 오는 날 골프장에서 누군가를 만났다면 한국 사람일 가능성이 크다");god=30000;break;
			case 7:System.out.println(s1="오늘은 그러는 의미에서 며칠 남지 않은 설날을 준비하는 중국 사람들의 이모저모를 카메라에 담아 보았습니다");god=60000;break;
			case 8:System.out.println(s1="북경은 최근 안개인지 매연인지 모를 정도로 공기가 상당히 나빠진 것 같습니다. 원래 북경은 겨울철만 되면 바람이 강하게 불어와");god=60000;break;
			case 9:System.out.println(s1="중국은 땅도 넓고 인구도 많아 설날의 대이동은 그다지 쉽지는 않습니다. 고향으로 내려가는 교통편을 알아보기 위해 열흘 전, 심지어는 한 달 전부터 미리 서둘러야 합니다");god=60000;break;
			default:
				out:
				while(true)
				{
					System.out.println("卧槽...你输入的是什么鬼？万能的开发者有这么好玩么<_<");
					System.out.print("好了，乖乖的在这里写下你的选择！：");
					serve=in.nextInt();
					if(serve>=1&&serve<=9)
					{
						switch(serve)
						{
						case 1:System.out.println(s1="신기한현상이다)");break out;
						case 2:System.out.println(s1="왜한국사람은골프에미칠까");break out;
						case 3:System.out.println(s1="고스톱처럼내기골프도이런저런반전의장치를만들었다");break out;
						case 4:System.out.println(s1="아무튼며칠전약간쌀쌀한날씨에짙은안개가자욱했던어느날.");god=30000;break out;
						case 5:System.out.println(s1="한국인에게골프의유전자가있는것이아니라골프에고스톱의유전자가있는 셈인가");god=30000;break out;
						case 6:System.out.println(s1="세계어디에서든비바람이불고눈이오는날골프장에서누군가를만났다면한국사람일가능성이크다");god=30000;break out ;
						case 7:System.out.println(s1="오늘은그러는의미에서며칠남지않은설날을준비하는중국사람들의이모저모를카메라에담아보았습니다");god=60000;break out;
						case 8:System.out.println(s1="북경은최근안개인지매연인지모를정도로공기가상당히나빠진것같습니다원래북경은겨울철만되면바람이강하게불어와");god=60000;break out ;
						case 9:System.out.println(s1="중국은땅도넓고인구도많아설날의대이동은그다지쉽지는않습니다고향으로내려가는교통편을알아보기위해열흘전심지어는한달전부터미리서둘러야합니다");god=60000;break out;
						default:break;
						}						
					}
				}break;
			}
			System.out.println("好了，看来施主生来乖巧！");
			System.out.println("下面呢，先把要求看完！");
			System.out.println("来来来，要开始了，深呼吸！请敲下“加油！”鼓劲，戳回车立马开始输入万能的开发者给您提供的韩文!然后回车表示打字结束！");
			System.out.println("临走前还有一句吩咐就是：如果你不喊加油，我就不开始了呢？啊哼！");
			in.next();
			System.out.println("开始！");
			long startMili=System.currentTimeMillis();
			in.nextLine();
			type=in.nextLine();
			long endMili=System.currentTimeMillis();
			long time=endMili-startMili;
			if(type.equals(s1))
			{
				if(time<=god&&time>=1)
				{
					System.out.println("好消息是你竟然全部打对了！*o*");
					System.out.println("不过，你竟然用了"+time/1000+"秒,人家钢琴家刘伟用脚都比你打的快耶!");
				}
				else if(time<1)
				{
					System.out.println("这么快，你是复制粘贴的，别以为我不知道！");
				}
				else
				{
					System.out.println("你全部打对了,用时"+time/1000+"秒,然而并没有什么卵用！");
				}
			}
			else
			{
				if(time<god&&time>=1)
				{
					System.out.println("你的速度很快,用时"+time/1000+"秒,然而并没有什么卵用！");
				}
				else if(time<1)
				{
					System.out.println("这么快，你是复制粘贴的，别以为我不知道！");
					System.out.println("而且，亲，你要复制也得复制对了哇?你是zu吗？");
				}
				else
				{
					System.out.println("This Speed。用时"+time/1000+"秒  >~< 举身赴清池，自挂东南枝！");
				}
			}
		}
		}}
